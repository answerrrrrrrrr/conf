import logging
import archinfo
import binascii
from lib import classifier
from capstone import *

# code = "\x48\x89\xe7" #mov %rsp,%rdi
# code = "\x48\x89\xe7\xc3"    #mov %rsp,%rdi; ret
# code = "\x48\x89\xe7\xff\x10" #mov %rsp,%rdi;call %rax
# code = "\x48\x89\xe7\xff\x23"  # mov %rsp,%rdi;jmp %rbx
# code = '\xc3'

# code = '\x83\xC4\x0C\x5B\x5E\x5F\x5D\xC3'

# code = '\x8d\x76\x00\xf3\xc3'
# code = '\x8b\x1c\x24\xc3'
# code = '\xff\x25\xc0\x97\x04\x08'
# code = '\x66\x90'

# code = '\x65\xff\x15\x10\x00\x00\x00'   # call gs:10h
# code = '\xcd\x80'   # int 80
# code = '\x0f\x05'   # syscall

# code = '\xcd\x80'

code = binascii.a2b_hex('eb29')
# code = binascii.a2b_hex('e8fcffffff')
# code = binascii.a2b_hex('e8fcffffff')


print binascii.b2a_hex(code)
md = Cs(CS_ARCH_X86, CS_MODE_64)
# md = Cs(CS_ARCH_X86, CS_MODE_64)
for i in md.disasm(code, 0x40000):
    print("0x{:x}\t{}\t{}".format(i.address, i.mnemonic, i.op_str))

cl = classifier.GadgetClassifier(arch=archinfo.ArchX86(
), validate_gadgets=False, log_level=logging.DEBUG)
# cl = classifier.GadgetClassifier(arch=archinfo.ArchAMD64(
# ), validate_gadgets=False, log_level=logging.DEBUG)

# gadget = cl.is_gadget(code, 0x40000)
# print gadget
