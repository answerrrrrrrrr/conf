import os
import magic


def get_type(path):
    if 'from_file' in dir(magic):
        return magic.from_file(path)
    else:
        m = magic.open(magic.MAGIC_NONE)
        m.load()
        return m.file(path)


def file_collector(root_path, file_filter='', include_root=True):
    for path, dirs, files in os.walk(root_path):
        for file in files:
            file_path = os.path.join(path, file)

            # pass links
            if not os.path.isfile(file_path):
                continue

            file_magic = get_type(file_path)
            # print file_path, file_magic
            if file_filter.lower() in file_magic.lower():
                if not include_root:
                    index = file_path.find(os.sep) + 1
                    file_path = file_path[index:] if index > 0 else ''
                yield file_path


if __name__ == '__main__':
    from pprint import pprint
    pprint(list(file_collector('elf', 'elf 32', include_root=False)))
    # pprint(list(file_collector('/Users/air9/Downloads', 'text')))
