#!/usr/bin/python

from __future__ import print_function
from keystone import *


def ks_asm(code, arch=KS_ARCH_X86, mode=KS_MODE_64, syntax=0):
    ks = Ks(arch, mode)
    if syntax != 0:
        ks.syntax = syntax

    encoding, count = ks.asm(code)
    # print(encoding)

    print('{} = '.format(code), end='')
    for i in encoding:
        print('{:02x} '.format(i), end='')
    print('')


# code = 'mov rax, rsp; syscall; nop; pop rbx; ret'
code = 'pop r12'
ks_asm(code)
# mov rax, rsp; syscall; nop; pop rbx; ret = 48 89 e0 0f 05 90 5b c3


for code in ['int3', 'int 3', 'int 80']:
    ks_asm(code, mode=KS_MODE_32)
