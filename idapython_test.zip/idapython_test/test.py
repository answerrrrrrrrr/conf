# class GadgetDetails(object):
#     def __init__(self, addr, br='', inst=''):
#         self._addr = addr
#         self._br = br
#         self._inst = inst
#         self._types = set()
#         self._clobbers = set()
#         self._fun_max_len = 0
#         self._nop_max_len = 0
#         self._call_preceded = False

#     @property
#     def addr(self):
#         return self._addr

#     @addr.setter
#     def addr(self, val):
#         self._addr = val


# if __name__ == '__main__':
#     gd = GadgetDetails('0x40000', 'ret', 'ret')
#     print gd.addr

class DotDict(dict):
    def __init__(self, *args, **kwargs):
        super(self.__class__, self).__init__(self, *args, **kwargs)

    def __getattr__(self, key):
        return self[key]

    def __setattr__(self, key, value):
        self[key] = value

    def __delattr__(self, key):
        del self[key]


class DottableDict(dict):
    def __init__(self, *args, **kwargs):
        super(self.__class__, self).__init__(self, *args, **kwargs)
        self.__dict__ = self

    def allowDotting(self, state=True):
        if state:
            self.__dict__ = self
        else:
            self.__dict__ = dict()


if __name__ == '__main__':
    d = DotDict()
    d.addr = '0x10000'
    print d.addr
    print d
    del d.addr
    print d

    d1 = dict()
    d2 = DottableDict()
    # print d1.__dict__   # AttributeError
    print d2.__dict__
    d2.attr = '0x10000'
    print d2.__dict__
