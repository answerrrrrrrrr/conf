#!/usr/bin/env python
# -*- coding: utf-8 -*-


import os
import subprocess
import fcollector


cwd = os.getcwd() + os.sep
idaq = '/Applications/idaq.app/Contents/MacOS/idaq'
elf_dir = 'elf/'
fragment_dir = 'fragment/'
script = 'gcollector.py'


for d in ['fragment', 'detail', 'pin']:
    if not os.path.exists(d):
        os.makedirs(d)


elfs = fcollector.file_collector(elf_dir, 'elf', include_root=False)
# from pprint import pprint
# pprint(list(elfs))


for elf in elfs:
    # name = '-'.join(elf.split(os.sep))
    name = elf.split(os.sep)[-1]
    output = ''.join([fragment_dir, name, '.txt'])

    # output_dir = os.path.dirname(output)
    # if not os.path.exists(output_dir):
    #     os.makedirs(output_dir)

    with open(output, 'w') as f:
        # 似乎试用版不能用批处理功能, 需要手动回车
        arg_S = ''.join(['-S"', cwd, script, ' ', cwd, output, '"'])
        arg_elf = elf_dir + elf
        cmd = ' '.join([idaq, arg_S, arg_elf])
        print cmd

        subprocess.call(cmd, shell=True)

# validate gadgets
subprocess.call('python gvalidator.py', shell=True)

# analyze gadgets
subprocess.call('python ganalyzer.py', shell=True)
