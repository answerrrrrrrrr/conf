Learn C The Hard Way

Online Video Course Plus PDFs $29

Python | Ruby | C | SQL | Regex

# Exercise 50: A Tiny Virtual Machine Part 3

# What You Should See

# How To Break It

# Extra Credit

Donate

Copyright (C) 2010 Zed. A. Shaw

Credits

 

















